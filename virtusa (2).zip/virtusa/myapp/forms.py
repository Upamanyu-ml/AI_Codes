from django import forms
NUMS=[0,1]
class UserForm(forms.Form):
	
    CODE_GENDER=forms.IntegerField(widget=forms.RadioSelect(choices=NUMS))
    DAYS_BIRTH=forms.DateField()
    # NAME_EDUCATION_TYPE=forms.IntegerField()
    # NAME_FAMILY_STATUS=forms.IntegerField()
    # AMT_INCOME_TOTAL=forms.IntegerField()
    # FLAG_EMP_PHONE=forms.IntegerField()
    # FLAG_PHONE=forms.IntegerField()
    # NAME_CONTRACT_TYPE=forms.IntegerField()
    # AMT_ANNUITY=forms.IntegerField()
    # AMT_CREDIT=forms.IntegerField()
    # AMT_REQ_CREDIT_BUREAU_QRT=forms.IntegerField()
    # NAME_HOUSING_TYPE=forms.IntegerField()
    # NAME_TYPE_SUITE=forms.IntegerField()
    # NAME_INCOME_TYPE=forms.IntegerField()
    # REGION_RATING_CLIENT=forms.IntegerField()
    # FLAG_OWN_CAR=forms.IntegerField()
    # APPLICATION_DATE=forms.IntegerField()
    # DAYS_LAST_PHONE_CHANGE=forms.IntegerField()
    # DAYS_ID_PUBLISH=forms.IntegerField()
