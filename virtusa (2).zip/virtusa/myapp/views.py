from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django import forms
from .forms import UserForm
from datetime import date,datetime
import pandas as pd
import pickle
from django.core.files import File

from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split


Model = pickle.load(open("C:/Users/Susmitha H/Pictures/Virtusa/Project/virtusa/myapp/files/Prediction_XGboost.sav", 'rb'))
Preprocessor=pickle.load(open("C:/Users/Susmitha H/Pictures/Virtusa/Project/virtusa/myapp/files/preprocessor_XGboost.sav", 'rb'))
default_values=pd.read_csv("C:/Users/Susmitha H/Pictures/Virtusa/Project/virtusa/myapp/files/median.csv")
def numOfDays(date1, date2):
    return float((date2-date1).days)
# Create your views here.
def index(request):
    return render(request, "myapp/index.html")

def decision(request):
	CODE_GENDER=float(request.POST['CODE_GENDER'])
	if CODE_GENDER==1:
		default_values["CODE_GENDER_F"]=1
	else:
		default_values["CODE_GENDER_M"]=0

	p=datetime.strptime(request.POST['DAYS_BIRTH'], '%Y-%m-%d')
	DAYS_BIRTH=numOfDays(p,datetime.today())
	default_values["DAYS_BIRTH"]=DAYS_BIRTH
	NAME_EDUCATION_TYPE=request.POST['NAME_EDUCATION_TYPE']
	a1='NAME_EDUCATION_TYPE_'+NAME_EDUCATION_TYPE
	print(a1)
	x1=["NAME_EDUCATION_TYPE_Higher education",
	"NAME_EDUCATION_TYPE_Incomplete higher",
	"NAME_EDUCATION_TYPE_Lower secondary",
	"NAME_EDUCATION_TYPE_Secondary / secondary special"]
	
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	print(default_values)
	NAME_FAMILY_STATUS=request.POST['NAME_FAMILY_STATUS']
	a1="NAME_FAMILY_STATUS_"+NAME_FAMILY_STATUS
	x1=["NAME_FAMILY_STATUS_Civil marriage",
	"NAME_FAMILY_STATUS_Married",
	"NAME_FAMILY_STATUS_Separated",
	"NAME_FAMILY_STATUS_Single / not married",
	"NAME_FAMILY_STATUS_Widow"]
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	AMT_INCOME_TOTAL=float(request.POST['AMT_INCOME_TOTAL'])
	default_values["AMT_INCOME_TOTAL"]=AMT_INCOME_TOTAL
	FLAG_EMP_PHONE=float(request.POST['FLAG_EMP_PHONE'])
	default_values["FLAG_EMP_PHONE"]=FLAG_EMP_PHONE
	FLAG_PHONE=float(request.POST['FLAG_PHONE'])
	default_values["FLAG_PHONE"]=FLAG_PHONE
	NAME_CONTRACT_TYPE=request.POST['NAME_CONTRACT_TYPE']
	a1="NAME_CONTRACT_TYPE_"+NAME_CONTRACT_TYPE
	x1=["NAME_CONTRACT_TYPE_Cash loans","NAME_CONTRACT_TYPE_Revolving loans"]
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	AMT_ANNUITY=float(request.POST['AMT_ANNUITY'])
	AMT_CREDIT=float(request.POST['AMT_CREDIT'])
	AMT_REQ_CREDIT_BUREAU_QRT=float(request.POST['AMT_REQ_CREDIT_BUREAU_QRT'])
	NAME_HOUSING_TYPE=request.POST['NAME_HOUSING_TYPE']
	a1="NAME_HOUSING_TYPE_"+NAME_HOUSING_TYPE
	x1=["NAME_HOUSING_TYPE_Co-op apartment",
	"NAME_HOUSING_TYPE_House / apartment",
	"NAME_HOUSING_TYPE_Municipal apartment",
	"NAME_HOUSING_TYPE_Office apartment",
	"NAME_HOUSING_TYPE_Rented apartment",
	"NAME_HOUSING_TYPE_With parents"]
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	NAME_TYPE_SUITE=request.POST['NAME_TYPE_SUITE']
	a1="NAME_TYPE_SUITE_"+NAME_TYPE_SUITE
	x1=["NAME_TYPE_SUITE_Children",
	"NAME_TYPE_SUITE_Family",
	"NAME_TYPE_SUITE_Group of people",
	"NAME_TYPE_SUITE_Other_A",
	"NAME_TYPE_SUITE_Other_B",
	"NAME_TYPE_SUITE_Spouse, partner",
	"NAME_TYPE_SUITE_Unaccompanied"]
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	NAME_INCOME_TYPE=request.POST['NAME_INCOME_TYPE']
	a1="NAME_INCOME_TYPE_"+NAME_INCOME_TYPE
	x1=[]
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	REGION_RATING_CLIENT=float(request.POST['REGION_RATING_CLIENT'])
	FLAG_OWN_CAR=request.POST['FLAG_OWN_CAR']
	a1="FLAG_OWN_CAR_"+FLAG_OWN_CAR
	x1=["FLAG_OWN_CAR_N","FLAG_OWN_CAR_Y"]
	for i in x1:
		if i==a1:
			default_values[i][0]=1
		else:
			default_values[i][0]=0
	APPLICATION_DATE=datetime.strptime(request.POST['APPLICATION_DATE'], '%Y-%m-%d')
	DAYS_LAST_PHONE_CHANGE=numOfDays(APPLICATION_DATE,datetime.strptime(request.POST['DAYS_LAST_PHONE_CHANGE'], '%Y-%m-%d'))
	DAYS_ID_PUBLISH=numOfDays(APPLICATION_DATE,datetime.strptime(request.POST['DAYS_ID_PUBLISH'], '%Y-%m-%d'))
	default_values["AMT_ANNUITY"]=AMT_ANNUITY
	default_values["AMT_CREDIT"]=AMT_CREDIT
	default_values["AMT_REQ_CREDIT_BUREAU_QRT"]=AMT_REQ_CREDIT_BUREAU_QRT
	default_values["REGION_RATING_CLIENT"]=REGION_RATING_CLIENT
	default_values["DAYS_LAST_PHONE_CHANGE"]=DAYS_LAST_PHONE_CHANGE*-1
	default_values["DAYS_ID_PUBLISH"]=DAYS_ID_PUBLISH*-1

	a=[CODE_GENDER,
	DAYS_BIRTH,
	NAME_EDUCATION_TYPE,
	NAME_FAMILY_STATUS,
	AMT_INCOME_TOTAL,
	FLAG_EMP_PHONE,
	FLAG_PHONE,
	NAME_CONTRACT_TYPE,
	AMT_ANNUITY,
	AMT_CREDIT,
	AMT_REQ_CREDIT_BUREAU_QRT,
	NAME_HOUSING_TYPE,
	NAME_TYPE_SUITE,
	NAME_INCOME_TYPE,
	REGION_RATING_CLIENT,
	FLAG_OWN_CAR,
	APPLICATION_DATE,
	DAYS_LAST_PHONE_CHANGE,
	DAYS_ID_PUBLISH]
	for i in a:
		print(i,type(i))



	a1=["CODE_GENDER",
	"DAYS_BIRTH",
	"NAME_EDUCATION_TYPE",
	"NAME_FAMILY_STATUS",
	"AMT_INCOME_TOTAL",
	"FLAG_EMP_PHONE",
	"FLAG_PHONE",
	"NAME_CONTRACT_TYPE",
	"AMT_ANNUITY",
	"AMT_CREDIT",
	"AMT_REQ_CREDIT_BUREAU_QRT",
	"NAME_HOUSING_TYPE",
	"NAME_TYPE_SUITE",
	"NAME_INCOME_TYPE",
	"REGION_RATING_CLIENT",
	"FLAG_OWN_CAR",
	"APPLICATION_DATE",
	"DAYS_LAST_PHONE_CHANGE",
	"DAYS_ID_PUBLISH"]
	for i in a1:
		if i in default_values.columns:
			print("********",i)
			print(default_values[i])

	for i in default_values.columns:
			print("********",i)
			print(default_values[i])		
	target=Model.predict(default_values.iloc[1,:])
	return render(request, "myapp/decision.html",{"decision": bool(target)})